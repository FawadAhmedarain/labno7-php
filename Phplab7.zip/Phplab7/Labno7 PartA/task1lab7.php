<?php 
for($i=1;$i<=50;$i++){
if($i%3==0){
	print($i." star"."<br>");
}
if($i%5==0){
	print($i." struck"."<br>");
}
if((($i%3)||($i%5))==0){
	print($i." star struck"."<br>");
}


}




?>