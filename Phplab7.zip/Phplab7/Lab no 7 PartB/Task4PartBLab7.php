<?php
$input = array(5, "5", "3", 5, 3, "3",1,"1",3);
$result = array_unique($input);
print_r($result);
?>